Exercise8-GroupSED

How we solved the exercise:
 - We solved the exercise very nice and quick

Problems we encountered:
 - We didn't have any problems


Fraction of the total workload:

Sara Kraettli: 33%
Elio Fritschi: 33%
Dave Meier: 33%
