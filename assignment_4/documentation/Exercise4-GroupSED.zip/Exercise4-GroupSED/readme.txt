Exercise4-GroupSED

We all got the OpenGL framework running on our machines.

Fraction of the total workload:

Sara Kraettli: 33%
Elio Fritschi: 33%
Dave Meier: 33%
